
module ObserverHomework {

	requires java.desktop;
}