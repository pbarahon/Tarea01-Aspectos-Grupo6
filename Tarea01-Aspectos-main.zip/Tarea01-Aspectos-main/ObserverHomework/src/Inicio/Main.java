package Inicio;
import Inicio.Main;

import GUI.MainPane;

public class Main  {

	public static void main(String[] args) {
		new MainPane();
	}



}
